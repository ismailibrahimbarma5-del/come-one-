CREATE DATABASE IF NOT EXISTS area_market;
-- The Node server automatically creates required tables.
-- Create an initial admin after starting the server using SQL:
-- INSERT INTO users (name,email,password_hash,role,approved)
-- VALUES ('Administrator','admin@example.com','REPLACE_WITH_BCRYPT_HASH','admin',1);
