# Area Market V2 — Real Backend Starter

This version uses a Node.js/Express API and MySQL for persistent users, products and orders.

## Requirements
- Node.js LTS
- MySQL 8+

## Setup
1. Create the database:
   `mysql -u root -p < backend/schema.sql`
2. In `backend`, run `npm install`.
3. Set DB environment variables if your MySQL settings differ:
   `DB_HOST`, `DB_USER`, `DB_PASSWORD`, `DB_NAME`, `JWT_SECRET`
4. Run:
   `npm start`
5. Serve `frontend/index.html` through a local web server (recommended) rather than opening it directly.
   Example with VS Code Live Server, or any static server.
6. Open the frontend URL.

## Security
This is a development starter. Before production, use HTTPS, a strong secret, secure cookies/token handling, validation, rate limiting, audit logs, backups, payment-provider webhooks, seller verification, and Nigerian legal/regulatory review. Medicine listings should be restricted to properly authorized pharmacies and prescription/controlled medicines should not be sold without required verification.
